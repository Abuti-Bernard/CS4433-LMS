# School Learning Management System (CS4433 Phase 4)

C++17 console application with an embedded SQLite database. It follows the layered design in the
System Design Document.

## Folder layout (matches the layers in the design)
| Layer | Files |
|---|---|
| Presentation (console menus) | `ConsoleApp.*`, `Input.*` |
| Service (rules + permissions) | `Services.*` |
| Domain (users, Strategy, Factory, data classes) | `Domain.*` |
| Data access (Repository pattern, all SQL) | `Repositories.*`, `Database.*` |
| Security | `Security.*` |

## Build on Windows (MSYS2 UCRT64)
Install once, in the MSYS2 UCRT64 terminal:

    pacman -S mingw-w64-ucrt-x86_64-gcc mingw-w64-ucrt-x86_64-sqlite3 mingw-w64-ucrt-x86_64-openssl

Then double-click `build.bat` (builds and starts the program), or press Ctrl+Shift+B in VS Code.
The build must compile ALL the .cpp files together, not just the open file.

## Build with CMake (Linux / any)
Needs a C++17 compiler, CMake 3.14+, SQLite and OpenSSL development files.

    sudo apt install build-essential cmake libsqlite3-dev libssl-dev
    mkdir build && cd build
    cmake .. && make

## Run
    ./lms              # uses lms.db in the current folder
    ./lms --demo       # also adds demo users, a course and two assignments
    ./lms other.db     # use a different database file

First run creates the administrator `admin` / `admin123`. Change it straight away.
Demo logins (password `pass123`): `hod1`, `lect1`, `stu1`, `stu2`.
Dates are typed as `YYYY-MM-DD HH:MM` 

## Rules implemented
* Late work is always accepted and marked LATE. Days late are counted from the student's
  effective deadline (their personal extension if they have one), rounded up.
* Penalty (Strategy `TenPercentPerDayPolicy`): 1-3 days late = raw mark - 10% x max mark x days;
  more than 3 days = 0. The final mark is calculated when needed and never stored.
* Resubmission only before the effective deadline and only while the work is unmarked.
  Every version is kept in `submission_versions`; the latest is marked.
* Students never see a mark or feedback until the HoD releases it. This is enforced in
  `SubmissionService::mySubmissions`, not in the menu.
* Every mark change (first mark, re-mark, HoD adjustment, HoD return) writes a `mark_audit` row
  (who, when, old, new, reason) in the same transaction as the change.
* A HoD return is stored in the audit table with old = new mark and the reason, so it is traceable.

## Security choices
* Passwords: PBKDF2-HMAC-SHA256 from OpenSSL, 100,000 iterations, 16-byte random salt per user
  (`Security.cpp`). Chosen because it is one well-known library call, needs no extra install on
  top of OpenSSL, and the iterations keep password guessing slow while a login still takes well under a second.
* All SQL uses prepared statements with bound values (`Statement::bind*`).
* Login errors use one message for wrong user or wrong password. Disabled accounts cannot log in.
* Every service method checks `user.can(permission)` and course/department ownership.
* Errors become `LmsError` / `DatabaseError` exceptions, shown as messages in the menu loop.