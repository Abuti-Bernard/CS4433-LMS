@echo off
rem Builds the LMS with MSYS2 UCRT64 g++ (install it with: pacman -S mingw-w64-ucrt-x86_64-gcc mingw-w64-ucrt-x86_64-sqlite3 mingw-w64-ucrt-x86_64-openssl)
set PATH=C:\msys64\ucrt64\bin;%PATH%
cd /d "%~dp0"
g++ -std=c++17 -Wall -Wextra -g main.cpp Database.cpp Domain.cpp Security.cpp Repositories.cpp Services.cpp Input.cpp ConsoleApp.cpp -o lms.exe -lsqlite3 -lcrypto
if errorlevel 1 (
    echo.
    echo BUILD FAILED
    pause
    exit /b 1
)
echo.
echo Build OK. Starting the program...
lms.exe --demo
pause
