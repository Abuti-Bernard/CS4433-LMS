#ifndef SECURITY_H_INCLUDED
#define SECURITY_H_INCLUDED

// Security.h - password hashing using OpenSSL (PBKDF2-HMAC-SHA256 with a random salt)
#include "Domain.h"
using namespace std;

class Pbkdf2Hasher : public IPasswordHasher {
public:
    string makeSalt() override;                                    
    string hash(const string& password, const string& salt) override;  
};

bool safeEquals(const string& a, const string& b);

#endif // SECURITY_H_INCLUDED
